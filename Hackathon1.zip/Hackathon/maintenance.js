(function () {
  'use strict';

  var STORAGE_KEY = 'portal_vehicles_in_shop';
  var LOGS_KEY = 'portal_service_logs';

  var serviceForm = document.getElementById('serviceForm');
  var logVehicle = document.getElementById('logVehicle');
  var logDate = document.getElementById('logDate');
  var logCost = document.getElementById('logCost');
  var logsTableBody = document.getElementById('logsTableBody');
  var logsCount = document.getElementById('logsCount');
  var newServicePanel = document.getElementById('newServicePanel');
  var btnCreateNewService = document.getElementById('btnCreateNewService');
  var btnCancelService = document.getElementById('btnCancelService');

  var vehicles = [
    { id: 'v1', name: 'Tata Ace (MH-12-1001)' },
    { id: 'v2', name: 'Ashok Leyland Dost (MH-14-2002)' },
    { id: 'v3', name: 'Eicher Pro (MH-01-3003)' },
    { id: 'v4', name: 'Mahindra Blazo (MH-02-5005)' },
    { id: 'v5', name: 'Bajaj Maxima (MH-43-4004)' }
  ];

  function getInShopIds() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return [];
      var arr = JSON.parse(raw);
      return Array.isArray(arr) ? arr : [];
    } catch (e) {
      return [];
    }
  }

  function setInShopIds(ids) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(ids));
    } catch (e) {}
  }

  function addToInShop(vehicleId) {
    var ids = getInShopIds();
    if (ids.indexOf(vehicleId) === -1) {
      ids.push(vehicleId);
      setInShopIds(ids);
    }
  }

  function removeFromInShop(vehicleId) {
    var ids = getInShopIds().filter(function (id) { return id !== vehicleId; });
    setInShopIds(ids);
  }

  function getLogs() {
    try {
      var raw = localStorage.getItem(LOGS_KEY);
      if (!raw) return [];
      var arr = JSON.parse(raw);
      return Array.isArray(arr) ? arr : [];
    } catch (e) {
      return [];
    }
  }

  function setLogs(logs) {
    try {
      localStorage.setItem(LOGS_KEY, JSON.stringify(logs));
    } catch (e) {}
  }

  function getVehicleName(id) {
    for (var i = 0; i < vehicles.length; i++) {
      if (vehicles[i].id === id) return vehicles[i].name;
    }
    return id;
  }

  function fillVehicleSelect() {
    if (!logVehicle) return;
    var inShop = getInShopIds();
    var current = logVehicle.value;
    logVehicle.innerHTML = '<option value="">Select vehicle...</option>';
    for (var i = 0; i < vehicles.length; i++) {
      var v = vehicles[i];
      if (inShop.indexOf(v.id) !== -1) continue;
      var opt = document.createElement('option');
      opt.value = v.id;
      opt.textContent = v.name;
      logVehicle.appendChild(opt);
    }
    if (current && logVehicle.querySelector('option[value="' + current + '"]')) {
      logVehicle.value = current;
    }
  }

  function escapeHtml(s) {
    var div = document.createElement('div');
    div.textContent = s == null ? '' : String(s);
    return div.innerHTML;
  }

  function renderLogs() {
    var logs = getLogs();
    if (!logsTableBody) return;
    logsTableBody.innerHTML = logs.length === 0
      ? '<tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:2rem;">No service logs yet.</td></tr>'
      : logs.map(function (log) {
          var statusClass = log.status === 'open' ? 'open' : 'closed';
          var statusLabel = log.status === 'open' ? 'New' : 'Completed';
          var rowClass = log.status === 'open' ? ' status-open' : '';
          var action = log.status === 'open'
            ? '<button type="button" class="btn-complete" data-id="' + log.id + '">Mark completed</button>'
            : '—';
          var costStr = (log.cost != null && log.cost !== '' && !isNaN(log.cost)) ? String(log.cost) + ' ₹' : '—';
          return '<tr class="' + rowClass + '">' +
            '<td>' + log.id + '</td>' +
            '<td>' + escapeHtml(log.vehicleName) + '</td>' +
            '<td>' + escapeHtml(log.notes || '—') + '</td>' +
            '<td>' + escapeHtml(log.date) + '</td>' +
            '<td>' + costStr + '</td>' +
            '<td><span class="status-badge ' + statusClass + '">' + statusLabel + '</span></td>' +
            '<td>' + action + '</td>' +
            '</tr>';
        }).join('');

    if (logsCount) logsCount.textContent = logs.length + ' log' + (logs.length === 1 ? '' : 's');

    logsTableBody.querySelectorAll('.btn-complete').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var id = parseInt(btn.getAttribute('data-id'), 10);
        var logs = getLogs();
        for (var i = 0; i < logs.length; i++) {
          if (logs[i].id === id && logs[i].status === 'open') {
            logs[i].status = 'closed';
            removeFromInShop(logs[i].vehicleId);
            setLogs(logs);
            fillVehicleSelect();
            renderLogs();
            return;
          }
        }
      });
    });
  }

  var nextLogId = 1;
  serviceForm.addEventListener('submit', function (e) {
    e.preventDefault();
    var vehicleId = (logVehicle && logVehicle.value) || '';
    var date = (logDate && logDate.value) || '';
    var type = (document.getElementById('logType') && document.getElementById('logType').value) || '';
    var notes = (document.getElementById('logNotes') && document.getElementById('logNotes').value) || '';
    var cost = (logCost && logCost.value) !== '' ? parseFloat(logCost.value) : null;

    if (!vehicleId || !date || !type) return;

    var logs = getLogs();
    var vehicleName = getVehicleName(vehicleId);
    logs.push({
      id: nextLogId++,
      vehicleId: vehicleId,
      vehicleName: vehicleName,
      date: date,
      type: type,
      notes: notes,
      cost: cost,
      status: 'open'
    });
    setLogs(logs);
    addToInShop(vehicleId);
    serviceForm.reset();
    logDate.value = new Date().toISOString().slice(0, 10);
    if (newServicePanel) newServicePanel.hidden = true;
    fillVehicleSelect();
    renderLogs();
  });

  if (btnCreateNewService) {
    btnCreateNewService.addEventListener('click', function () {
      if (newServicePanel) newServicePanel.hidden = false;
      fillVehicleSelect();
    });
  }
  if (btnCancelService) {
    btnCancelService.addEventListener('click', function () {
      if (newServicePanel) newServicePanel.hidden = true;
    });
  }

  if (logDate) {
    logDate.value = new Date().toISOString().slice(0, 10);
  }
  fillVehicleSelect();
  var existing = getLogs();
  if (existing.length > 0) {
    var maxId = 0;
    for (var j = 0; j < existing.length; j++) {
      if (existing[j].id > maxId) maxId = existing[j].id;
    }
    nextLogId = maxId + 1;
  }
  renderLogs();
})();
