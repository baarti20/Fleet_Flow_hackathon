(function () {
  'use strict';

  var filterVehicleType = document.getElementById('filterVehicleType');
  var filterStatus = document.getElementById('filterStatus');
  var filterRegion = document.getElementById('filterRegion');
  var resetFiltersBtn = document.getElementById('resetFilters');
  var fleetTableBody = document.getElementById('fleetTableBody');
  var summaryCount = document.getElementById('summaryCount');
  var kpiActive = document.getElementById('kpiActive');
  var kpiMaintenance = document.getElementById('kpiMaintenance');
  var kpiUtilization = document.getElementById('kpiUtilization');
  var kpiCargo = document.getElementById('kpiCargo');

  var FLEET = (function () {
    var data = [];
    var types = ['truck', 'van', 'bike'];
    var statuses = ['on_trip', 'idle', 'in_shop'];
    var regions = ['north', 'south', 'east', 'west'];

    for (var i = 1; i <= 100; i++) {
      var type = types[i % types.length];
      var status = statuses[i % statuses.length];
      var region = regions[i % regions.length];
      data.push({
        id: i,
        vehicle: 'VH-' + (100 + i),
        type: type,
        status: status,
        region: region
      });
    }
    return data;
  })();

  var PENDING_CARGO = 42;

  function getFilters() {
    return {
      vehicleType: (filterVehicleType && filterVehicleType.value) || '',
      status: (filterStatus && filterStatus.value) || '',
      region: (filterRegion && filterRegion.value) || ''
    };
  }

  function filterFleet(list) {
    var f = getFilters();
    return list.filter(function (v) {
      if (f.vehicleType && v.type !== f.vehicleType) return false;
      if (f.status && v.status !== f.status) return false;
      if (f.region && v.region !== f.region) return false;
      return true;
    });
  }

  function computeKpis(list) {
    var active = list.filter(function (v) { return v.status === 'on_trip'; }).length;
    var inShop = list.filter(function (v) { return v.status === 'in_shop'; }).length;
    var onTrip = active;
    var idle = list.filter(function (v) { return v.status === 'idle'; }).length;
    var assignable = onTrip + idle;
    var utilization = assignable ? Math.round((onTrip / assignable) * 100) : 0;
    return {
      active: active,
      maintenance: inShop,
      utilization: utilization + '%',
      cargo: PENDING_CARGO
    };
  }

  function typeLabel(type) {
    return type ? type.charAt(0).toUpperCase() + type.slice(1) : '';
  }

  function statusLabel(status) {
    var map = { on_trip: 'On Trip', idle: 'Idle', in_shop: 'In Shop' };
    return map[status] || status;
  }

  function regionLabel(region) {
    return region ? region.charAt(0).toUpperCase() + region.slice(1) : '';
  }

  function renderTable(list) {
    if (!fleetTableBody) return;
    fleetTableBody.innerHTML = list.length
      ? list.map(function (v) {
          return '<tr><td>' + v.vehicle + '</td><td>' + typeLabel(v.type) + '</td><td><span class="status-badge ' + v.status + '">' + statusLabel(v.status) + '</span></td><td>' + regionLabel(v.region) + '</td></tr>';
        }).join('')
      : '<tr><td colspan="4" style="text-align:center;color:var(--text-muted);padding:2rem;">No vehicles match the current filters.</td></tr>';
  }

  function updateSummaryCount(list) {
    if (summaryCount) summaryCount.textContent = 'Showing ' + list.length + ' vehicle' + (list.length === 1 ? '' : 's');
  }

  function updateKpis(kpis) {
    if (kpiActive) kpiActive.textContent = kpis.active;
    if (kpiMaintenance) kpiMaintenance.textContent = kpis.maintenance;
    if (kpiUtilization) kpiUtilization.textContent = kpis.utilization;
    if (kpiCargo) kpiCargo.textContent = kpis.cargo;
  }

  function refresh() {
    var filtered = filterFleet(FLEET);
    var kpis = computeKpis(filtered);
    updateKpis(kpis);
    renderTable(filtered);
    updateSummaryCount(filtered);
  }

  if (filterVehicleType) filterVehicleType.addEventListener('change', refresh);
  if (filterStatus) filterStatus.addEventListener('change', refresh);
  if (filterRegion) filterRegion.addEventListener('change', refresh);

  if (resetFiltersBtn) {
    resetFiltersBtn.addEventListener('click', function () {
      if (filterVehicleType) filterVehicleType.value = '';
      if (filterStatus) filterStatus.value = '';
      if (filterRegion) filterRegion.value = '';
      refresh();
    });
  }

  refresh();
})();
