(function () {
  'use strict';

  var PROFILES_KEY = 'portal_driver_profiles';

  var profilesTableBody = document.getElementById('profilesTableBody');
  var editModal = document.getElementById('editModal');
  var modalBackdrop = document.getElementById('modalBackdrop');
  var closeModalBtn = document.getElementById('closeModal');
  var btnCancelEdit = document.getElementById('btnCancelEdit');
  var profileForm = document.getElementById('profileForm');
  var profileDriverId = document.getElementById('profileDriverId');
  var profileLicenseExpiry = document.getElementById('profileLicenseExpiry');
  var profileCompletionRate = document.getElementById('profileCompletionRate');
  var profileSafetyScore = document.getElementById('profileSafetyScore');
  var profileStatus = document.getElementById('profileStatus');

  var drivers = [
    { id: 'd1', name: 'Raj Kumar' },
    { id: 'd2', name: 'Amit Sharma' },
    { id: 'd3', name: 'Priya Singh' },
    { id: 'd4', name: 'Vikram Patel' },
    { id: 'd5', name: 'Sneha Reddy' }
  ];

  function getDefaultProfile() {
    var d = new Date();
    d.setFullYear(d.getFullYear() + 1);
    return {
      licenseExpiry: d.toISOString().slice(0, 10),
      tripCompletionRate: 100,
      safetyScore: 100,
      status: 'on_duty'
    };
  }

  function getProfiles() {
    try {
      var raw = localStorage.getItem(PROFILES_KEY);
      if (!raw) return {};
      return JSON.parse(raw);
    } catch (e) {
      return {};
    }
  }

  function setProfiles(profiles) {
    try {
      localStorage.setItem(PROFILES_KEY, JSON.stringify(profiles));
    } catch (e) {}
  }

  function getProfile(driverId) {
    var all = getProfiles();
    if (all[driverId]) return all[driverId];
    var def = getDefaultProfile();
    all[driverId] = def;
    setProfiles(all);
    return def;
  }

  function setProfile(driverId, profile) {
    var all = getProfiles();
    all[driverId] = profile;
    setProfiles(all);
  }

  function isLicenseExpired(expiryStr) {
    if (!expiryStr) return true;
    return expiryStr < new Date().toISOString().slice(0, 10);
  }

  function statusLabel(status) {
    var map = { on_duty: 'On Duty', off_duty: 'Off Duty', suspended: 'Suspended' };
    return map[status] || status;
  }

  function escapeHtml(s) {
    var div = document.createElement('div');
    div.textContent = s == null ? '' : String(s);
    return div.innerHTML;
  }

  function openEdit(driverId) {
    var d = drivers.find(function (x) { return x.id === driverId; });
    if (!d) return;
    var p = getProfile(driverId);
    profileDriverId.value = driverId;
    profileLicenseExpiry.value = p.licenseExpiry || '';
    profileCompletionRate.value = p.tripCompletionRate != null ? p.tripCompletionRate : 100;
    profileSafetyScore.value = p.safetyScore != null ? p.safetyScore : 100;
    profileStatus.value = p.status || 'on_duty';
    editModal.hidden = false;
  }

  function closeEdit() {
    editModal.hidden = true;
  }

  function render() {
    if (!profilesTableBody) return;
    var html = drivers.map(function (d) {
      var p = getProfile(d.id);
      var expired = isLicenseExpired(p.licenseExpiry);
      var blocked = expired || p.status === 'suspended';
      var rowClass = blocked ? ' class="blocked"' : '';
      var expiryClass = expired ? 'expired' : 'valid';
      var expiryText = expired ? 'Expired' : (p.licenseExpiry || '—');
      var statusOpts = ['on_duty', 'off_duty', 'suspended'].map(function (s) {
        var sel = p.status === s ? ' selected' : '';
        return '<option value="' + s + '"' + sel + '>' + statusLabel(s) + '</option>';
      }).join('');
      return '<tr' + rowClass + '>' +
        '<td>' + escapeHtml(d.name) + '</td>' +
        '<td><span class="expiry-badge ' + expiryClass + '">' + escapeHtml(p.licenseExpiry || '—') + '</span> ' + (expired ? '<span class="expiry-badge expired">Expired</span>' : '') + '</td>' +
        '<td>' + (p.tripCompletionRate != null ? p.tripCompletionRate + '%' : '—') + '</td>' +
        '<td>' + (p.safetyScore != null ? p.safetyScore : '—') + '</td>' +
        '<td><select class="status-select" data-id="' + d.id + '">' + statusOpts + '</select></td>' +
        '<td><button type="button" class="btn-edit" data-id="' + d.id + '">Edit</button></td>' +
        '</tr>';
    }).join('');
    profilesTableBody.innerHTML = html;

    profilesTableBody.querySelectorAll('.status-select').forEach(function (sel) {
      sel.addEventListener('change', function () {
        var id = sel.getAttribute('data-id');
        var p = getProfile(id);
        p.status = sel.value;
        setProfile(id, p);
        render();
      });
    });
    profilesTableBody.querySelectorAll('.btn-edit').forEach(function (btn) {
      btn.addEventListener('click', function () {
        openEdit(btn.getAttribute('data-id'));
      });
    });
  }

  profileForm.addEventListener('submit', function (e) {
    e.preventDefault();
    var id = profileDriverId.value;
    if (!id) return;
    var p = {
      licenseExpiry: profileLicenseExpiry.value,
      tripCompletionRate: parseInt(profileCompletionRate.value, 10),
      safetyScore: parseInt(profileSafetyScore.value, 10),
      status: profileStatus.value
    };
    setProfile(id, p);
    closeEdit();
    render();
  });

  if (closeModalBtn) closeModalBtn.addEventListener('click', closeEdit);
  if (modalBackdrop) modalBackdrop.addEventListener('click', closeEdit);
  if (btnCancelEdit) btnCancelEdit.addEventListener('click', closeEdit);

  render();
})();
