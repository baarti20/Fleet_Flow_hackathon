/**
 * FleetFlow API Server
 * Express + SQLite backend - serves static files and REST API
 */
const express = require('express');
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_PATH = path.join(__dirname, 'database', 'fleetflow.db');

app.use(function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});
app.use(express.json());
app.use(express.static(__dirname));

let db;

function initDb() {
  const dbDir = path.join(__dirname, 'database');
  if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });
  const schemaPath = path.join(__dirname, 'database', 'schema.sql');
  const seedPath = path.join(__dirname, 'database', 'seed.sql');
  const schema = fs.readFileSync(schemaPath, 'utf8');
  db = new Database(DB_PATH);
  db.exec(schema);
  const count = db.prepare('SELECT COUNT(*) as c FROM vehicles').get();
  if (count.c === 0 && fs.existsSync(seedPath)) {
    const seed = fs.readFileSync(seedPath, 'utf8');
    db.exec(seed);
    console.log('Database seeded with sample data (105 vehicles).');
  } else if (count.c > 0 && count.c < 105) {
    const seed100Path = path.join(__dirname, 'database', 'seed-100-vehicles.sql');
    if (fs.existsSync(seed100Path)) {
      const seed100 = fs.readFileSync(seed100Path, 'utf8');
      db.exec(seed100);
      console.log('Database: added 100-vehicle seed (INSERT OR IGNORE).');
    }
  }
}

// ============ API Routes ============

app.get('/api/vehicles', (req, res) => {
  try {
    const rows = db.prepare('SELECT * FROM vehicles ORDER BY id').all();
    res.json(rows.map(r => ({
      id: r.id,
      name: r.name,
      licensePlate: r.license_plate,
      maxLoadKg: r.max_load_kg,
      odometer: r.odometer,
      outOfService: !!r.out_of_service,
      type: r.type || 'truck',
      region: r.region || 'north'
    })));
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/vehicles', (req, res) => {
  try {
    const { name, licensePlate, maxLoadKg, odometer, type, region } = req.body;
    const id = 'v' + (db.prepare('SELECT MAX(CAST(SUBSTR(id,2) AS INT)) as m FROM vehicles WHERE id GLOB "v*"').get()?.m || 0) + 1);
    const vehicleType = (type && ['truck', 'van', 'bike'].includes(type)) ? type : 'truck';
    const vehicleRegion = (region && ['north', 'south', 'east', 'west'].includes(region)) ? region : 'north';
    db.prepare('INSERT INTO vehicles (id, name, license_plate, max_load_kg, odometer, type, region) VALUES (?, ?, ?, ?, ?, ?, ?)')
      .run(id, name, licensePlate, maxLoadKg, odometer || 0, vehicleType, vehicleRegion);
    res.status(201).json({ id, name, licensePlate, maxLoadKg, odometer: odometer || 0, outOfService: false, type: vehicleType, region: vehicleRegion });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.put('/api/vehicles/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { name, licensePlate, maxLoadKg, odometer, type, region } = req.body;
    const vehicleType = (type && ['truck', 'van', 'bike'].includes(type)) ? type : undefined;
    const vehicleRegion = (region && ['north', 'south', 'east', 'west'].includes(region)) ? region : undefined;
    const rowBefore = db.prepare('SELECT * FROM vehicles WHERE id=?').get(id);
    if (!rowBefore) return res.status(404).json({ error: 'Not found' });
    db.prepare('UPDATE vehicles SET name=?, license_plate=?, max_load_kg=?, odometer=?, type=?, region=?, updated_at=CURRENT_TIMESTAMP WHERE id=?')
      .run(name, licensePlate, maxLoadKg, odometer, vehicleType != null ? vehicleType : rowBefore.type, vehicleRegion != null ? vehicleRegion : rowBefore.region, id);
    const row = db.prepare('SELECT * FROM vehicles WHERE id=?').get(id);
    res.json({ id: row.id, name: row.name, licensePlate: row.license_plate, maxLoadKg: row.max_load_kg, odometer: row.odometer, outOfService: !!row.out_of_service, type: row.type || 'truck', region: row.region || 'north' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.patch('/api/vehicles/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { outOfService } = req.body;
    db.prepare('UPDATE vehicles SET out_of_service=?, updated_at=CURRENT_TIMESTAMP WHERE id=?').run(outOfService ? 1 : 0, id);
    const row = db.prepare('SELECT * FROM vehicles WHERE id=?').get(id);
    if (!row) return res.status(404).json({ error: 'Not found' });
    res.json({ id: row.id, outOfService: !!row.out_of_service, type: row.type || 'truck', region: row.region || 'north' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.delete('/api/vehicles/:id', (req, res) => {
  try {
    const { id } = req.params;
    db.prepare('DELETE FROM vehicles WHERE id=?').run(id);
    res.status(204).send();
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/drivers', (req, res) => {
  try {
    const rows = db.prepare('SELECT * FROM drivers ORDER BY id').all();
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/driver-profiles', (req, res) => {
  try {
    const rows = db.prepare('SELECT * FROM driver_profiles').all();
    const obj = {};
    rows.forEach(r => { obj[r.driver_id] = { licenseExpiry: r.license_expiry, tripCompletionRate: r.trip_completion_rate, safetyScore: r.safety_score, status: r.status }; });
    res.json(obj);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.put('/api/driver-profiles/:driverId', (req, res) => {
  try {
    const { driverId } = req.params;
    const { licenseExpiry, tripCompletionRate, safetyScore, status } = req.body;
    db.prepare(`INSERT INTO driver_profiles (driver_id, license_expiry, trip_completion_rate, safety_score, status, updated_at)
      VALUES (?,?,?,?,?,CURRENT_TIMESTAMP)
      ON CONFLICT(driver_id) DO UPDATE SET license_expiry=excluded.license_expiry, trip_completion_rate=excluded.trip_completion_rate,
      safety_score=excluded.safety_score, status=excluded.status, updated_at=CURRENT_TIMESTAMP`).run(driverId, licenseExpiry || null, tripCompletionRate ?? 100, safetyScore ?? 100, status || 'on_duty');
    const r = db.prepare('SELECT * FROM driver_profiles WHERE driver_id=?').get(driverId);
    res.json({ licenseExpiry: r.license_expiry, tripCompletionRate: r.trip_completion_rate, safetyScore: r.safety_score, status: r.status });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/trips', (req, res) => {
  try {
    const rows = db.prepare(`SELECT t.*, v.name as vehicle_name, d.name as driver_name
      FROM trips t LEFT JOIN vehicles v ON t.vehicle_id=v.id LEFT JOIN drivers d ON t.driver_id=d.id ORDER BY t.id DESC`).all();
    res.json(rows.map(r => ({
      id: r.id, pointA: r.origin, pointB: r.destination, vehicleId: r.vehicle_id, vehicleName: r.vehicle_name,
      driverId: r.driver_id, driverName: r.driver_name, cargoWeight: r.cargo_weight_kg, maxCapacity: r.max_capacity_kg, status: r.status
    })));
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/trips', (req, res) => {
  try {
    const { origin, destination, vehicleId, driverId, cargoWeightKg, maxCapacityKg } = req.body;
    const r = db.prepare(`INSERT INTO trips (origin, destination, vehicle_id, driver_id, cargo_weight_kg, max_capacity_kg, status)
      VALUES (?,?,?,?,?,?,?)`).run(origin, destination, vehicleId, driverId, cargoWeightKg, maxCapacityKg, 'draft');
    const row = db.prepare(`SELECT t.*, v.name as vehicle_name, d.name as driver_name FROM trips t
      LEFT JOIN vehicles v ON t.vehicle_id=v.id LEFT JOIN drivers d ON t.driver_id=d.id WHERE t.id=?`).get(r.lastInsertRowid);
    res.status(201).json({
      id: row.id, pointA: row.origin, pointB: row.destination, vehicleId: row.vehicle_id, vehicleName: row.vehicle_name,
      driverId: row.driver_id, driverName: row.driver_name, cargoWeight: row.cargo_weight_kg, maxCapacity: row.max_capacity_kg, status: row.status
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.patch('/api/trips/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    db.prepare('UPDATE trips SET status=?, updated_at=CURRENT_TIMESTAMP WHERE id=?').run(status, id);
    const row = db.prepare(`SELECT t.*, v.name as vehicle_name, d.name as driver_name FROM trips t
      LEFT JOIN vehicles v ON t.vehicle_id=v.id LEFT JOIN drivers d ON t.driver_id=d.id WHERE t.id=?`).get(id);
    if (!row) return res.status(404).json({ error: 'Not found' });
    res.json({ id: row.id, status: row.status, vehicleName: row.vehicle_name, driverName: row.driver_name });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/vehicles-in-shop', (req, res) => {
  try {
    const rows = db.prepare('SELECT vehicle_id FROM vehicles_in_shop').all();
    res.json(rows.map(r => r.vehicle_id));
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/vehicles-in-shop', (req, res) => {
  try {
    const { vehicleId } = req.body;
    db.prepare('INSERT OR IGNORE INTO vehicles_in_shop (vehicle_id) VALUES (?)').run(vehicleId);
    res.status(201).json({ vehicleId });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.delete('/api/vehicles-in-shop/:vehicleId', (req, res) => {
  try {
    db.prepare('DELETE FROM vehicles_in_shop WHERE vehicle_id=?').run(req.params.vehicleId);
    res.status(204).send();
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/service-logs', (req, res) => {
  try {
    const rows = db.prepare(`SELECT l.*, v.name as vehicle_name FROM service_logs l LEFT JOIN vehicles v ON l.vehicle_id=v.id ORDER BY l.id DESC`).all();
    res.json(rows.map(r => ({
      id: r.id, vehicleId: r.vehicle_id, vehicleName: r.vehicle_name, date: r.date, type: r.type, notes: r.notes, cost: r.cost, status: r.status
    })));
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/service-logs', (req, res) => {
  try {
    const { vehicleId, date, type, notes, cost } = req.body;
    const v = db.prepare('SELECT name FROM vehicles WHERE id=?').get(vehicleId);
    const r = db.prepare('INSERT INTO service_logs (vehicle_id, date, type, notes, cost, status) VALUES (?,?,?,?,?,?)')
      .run(vehicleId, date, type, notes || null, cost || null, 'open');
    db.prepare('INSERT OR IGNORE INTO vehicles_in_shop (vehicle_id) VALUES (?)').run(vehicleId);
    res.status(201).json({ id: r.lastInsertRowid, vehicleId, vehicleName: v?.name, date, type, notes, cost, status: 'open' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.patch('/api/service-logs/:id', (req, res) => {
  try {
    const { id } = req.params;
    const log = db.prepare('SELECT * FROM service_logs WHERE id=?').get(id);
    if (!log) return res.status(404).json({ error: 'Not found' });
    db.prepare('UPDATE service_logs SET status=? WHERE id=?').run('closed', id);
    db.prepare('DELETE FROM vehicles_in_shop WHERE vehicle_id=?').run(log.vehicle_id);
    res.json({ id: parseInt(id, 10), status: 'closed' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/fuel-logs', (req, res) => {
  try {
    const rows = db.prepare('SELECT * FROM fuel_logs ORDER BY date DESC, id DESC').all();
    res.json(rows.map(r => ({ id: r.id, vehicleId: r.vehicle_id, vehicleName: r.vehicle_name, liters: r.liters, cost: r.cost, distance: r.distance_km, date: r.date })));
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/fuel-logs', (req, res) => {
  try {
    const { vehicleId, liters, cost, distance, date } = req.body;
    const v = db.prepare('SELECT name FROM vehicles WHERE id=?').get(vehicleId);
    const r = db.prepare('INSERT INTO fuel_logs (vehicle_id, vehicle_name, liters, cost, distance_km, date) VALUES (?,?,?,?,?,?)')
      .run(vehicleId, v?.name, liters, cost, distance || null, date);
    res.status(201).json({ id: r.lastInsertRowid, vehicleId, vehicleName: v?.name, liters, cost, distance, date });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/maintenance-costs', (req, res) => {
  try {
    const rows = db.prepare('SELECT * FROM maintenance_costs ORDER BY date DESC, id DESC').all();
    res.json(rows.map(r => ({ id: r.id, vehicleId: r.vehicle_id, vehicleName: r.vehicle_name, cost: r.cost, date: r.date, notes: r.notes })));
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/maintenance-costs', (req, res) => {
  try {
    const { vehicleId, cost, date, notes } = req.body;
    const v = db.prepare('SELECT name FROM vehicles WHERE id=?').get(vehicleId);
    const r = db.prepare('INSERT INTO maintenance_costs (vehicle_id, vehicle_name, cost, date, notes) VALUES (?,?,?,?,?)')
      .run(vehicleId, v?.name, cost, date, notes || null);
    res.status(201).json({ id: r.lastInsertRowid, vehicleId, vehicleName: v?.name, cost, date, notes });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/vehicle-roi-config', (req, res) => {
  try {
    const rows = db.prepare('SELECT * FROM vehicle_roi_config').all();
    const obj = {};
    rows.forEach(r => { obj[r.vehicle_id] = { acquisitionCost: r.acquisition_cost, revenue: r.revenue }; });
    res.json(obj);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.put('/api/vehicle-roi-config/:vehicleId', (req, res) => {
  try {
    const { vehicleId } = req.params;
    const { acquisitionCost, revenue } = req.body;
    db.prepare(`INSERT INTO vehicle_roi_config (vehicle_id, acquisition_cost, revenue, updated_at) VALUES (?,?,?,CURRENT_TIMESTAMP)
      ON CONFLICT(vehicle_id) DO UPDATE SET acquisition_cost=excluded.acquisition_cost, revenue=excluded.revenue, updated_at=CURRENT_TIMESTAMP`).run(vehicleId, acquisitionCost, revenue);
    const r = db.prepare('SELECT * FROM vehicle_roi_config WHERE vehicle_id=?').get(vehicleId);
    res.json({ acquisitionCost: r.acquisition_cost, revenue: r.revenue });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/fleet', (req, res) => {
  try {
    const vehicles = db.prepare('SELECT * FROM vehicles').all();
    const inShop = db.prepare('SELECT vehicle_id FROM vehicles_in_shop').all();
    const inShopSet = new Set(inShop.map(r => r.vehicle_id));
    const trips = db.prepare('SELECT vehicle_id FROM trips WHERE status IN ("draft","dispatched")').all();
    const onTripSet = new Set(trips.map(r => r.vehicle_id));
    const list = vehicles.map(v => ({
      id: v.id,
      vehicle: v.name || v.id,
      type: v.type || 'truck',
      status: onTripSet.has(v.id) ? 'on_trip' : inShopSet.has(v.id) ? 'in_shop' : 'idle',
      region: v.region || 'north'
    }));
    res.json(list);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/auth/register', (req, res) => {
  try {
    const { email, password, name, role } = req.body;
    const hash = 'hash_' + (password || '').substring(0, 8);
    db.prepare('INSERT INTO users (email, password_hash, name, role) VALUES (?,?,?,?)').run(email, hash, name, role);
    res.status(201).json({ email, role });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/auth/login', (req, res) => {
  try {
    const { email, role } = req.body;
    const u = db.prepare('SELECT * FROM users WHERE email=? AND role=?').get(email, role);
    if (u) res.json({ email: u.email, role: u.role });
    else res.status(401).json({ error: 'Invalid credentials' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

initDb();

app.listen(PORT, () => {
  console.log('FleetFlow server at http://localhost:' + PORT);
});
