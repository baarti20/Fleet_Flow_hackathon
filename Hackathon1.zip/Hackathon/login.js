(function () {
  'use strict';

  var loginForm = document.getElementById('loginForm');
  var forgotModal = document.getElementById('forgotModal');
  var forgotLink = document.getElementById('forgotPassword');
  var closeForgot = document.getElementById('closeForgot');
  var modalBackdrop = document.getElementById('modalBackdrop');
  var forgotForm = document.getElementById('forgotForm');
  var messageEl = document.getElementById('message');
  var submitBtn = document.getElementById('submitBtn');
  var emailInput = document.getElementById('email');
  var passwordInput = document.getElementById('password');
  var roleInput = document.getElementById('role');
  var roleError = document.getElementById('roleError');
  var emailError = document.getElementById('emailError');
  var passwordError = document.getElementById('passwordError');
  var forgotMessage = document.getElementById('forgotMessage');
  var forgotEmailInput = document.getElementById('forgotEmail');
  var roleTabs = document.querySelectorAll('.role-tab');

  function showMessage(el, text, type) {
    el.textContent = text;
    el.className = 'message ' + (type || '');
    el.style.display = text ? 'block' : 'none';
  }

  function clearFieldErrors() {
    roleError.textContent = '';
    emailError.textContent = '';
    passwordError.textContent = '';
  }

  function validateEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  // Role tabs: sync hidden input and aria-pressed
  roleTabs.forEach(function (tab) {
    tab.addEventListener('click', function () {
      var role = tab.getAttribute('data-role') || '';
      roleInput.value = role;
      roleError.textContent = '';
      roleTabs.forEach(function (t) {
        t.setAttribute('aria-pressed', t === tab ? 'true' : 'false');
      });
    });
  });

  // Role-Based Access Control
  var RBAC = {
    manager: {
      label: 'Manager',
      redirect: 'dashboard.html',
      welcome: 'Welcome, Manager! Loading Dashboard...'
    },
    dispatcher: {
      label: 'Dispatcher',
      redirect: 'dispatcher.html',
      welcome: 'Welcome, Dispatcher! Loading Dispatcher...'
    }
  };

  loginForm.addEventListener('submit', function (e) {
    e.preventDefault();
    clearFieldErrors();
    messageEl.textContent = '';
    messageEl.className = 'message';
    messageEl.style.display = 'none';

    var role = (roleInput.value || '').trim().toLowerCase();
    var email = (emailInput.value || '').trim();
    var password = passwordInput.value;

    var hasError = false;
    if (!role) {
      roleError.textContent = 'Please select a role.';
      hasError = true;
    }
    if (!email) {
      emailError.textContent = 'Email is required.';
      hasError = true;
    } else if (!validateEmail(email)) {
      emailError.textContent = 'Please enter a valid email.';
      hasError = true;
    }
    if (!password) {
      passwordError.textContent = 'Password is required.';
      hasError = true;
    }
    if (hasError) return;

    submitBtn.disabled = true;

    setTimeout(function () {
      var rbac = RBAC[role];
      if (rbac) {
        showMessage(messageEl, rbac.welcome, 'success');
        try {
          sessionStorage.setItem('userRole', role);
          sessionStorage.setItem('userEmail', email);
        } catch (err) {}
        setTimeout(function () {
          window.location.href = rbac.redirect;
        }, 700);
      } else {
        showMessage(messageEl, 'Invalid role.', 'error');
      }
      submitBtn.disabled = false;
    }, 600);
  });

  // Forgot Password
  forgotLink.addEventListener('click', function (e) {
    e.preventDefault();
    forgotModal.hidden = false;
    forgotMessage.textContent = '';
    forgotMessage.className = 'message modal-msg';
    forgotEmailInput.value = '';
    setTimeout(function () { forgotEmailInput.focus(); }, 100);
  });

  closeForgot.addEventListener('click', function () {
    forgotModal.hidden = true;
  });

  if (modalBackdrop) {
    modalBackdrop.addEventListener('click', function () {
      forgotModal.hidden = true;
    });
  }

  forgotModal.addEventListener('click', function (e) {
    if (e.target === forgotModal) forgotModal.hidden = true;
  });

  forgotForm.addEventListener('submit', function (e) {
    e.preventDefault();
    var email = (forgotEmailInput.value || '').trim();
    if (!validateEmail(email)) {
      forgotMessage.textContent = 'Please enter a valid email.';
      forgotMessage.className = 'message modal-msg error';
      return;
    }
    forgotMessage.textContent = 'Reset link sent to ' + email + ' (demo).';
    forgotMessage.className = 'message modal-msg success';
  });
})();
