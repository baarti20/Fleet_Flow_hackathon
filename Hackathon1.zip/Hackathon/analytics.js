(function () {
  'use strict';

  var FUEL_KEY = 'portal_fuel_logs';
  var MAINT_KEY = 'portal_maintenance_costs';
  var PROFILES_KEY = 'portal_driver_profiles';
  var ROI_CONFIG_KEY = 'portal_vehicle_roi_config';

  var fuelEfficiencyBody = document.getElementById('fuelEfficiencyBody');
  var roiBody = document.getElementById('roiBody');
  var payrollCsv = document.getElementById('payrollCsv');
  var payrollPdf = document.getElementById('payrollPdf');
  var healthCsv = document.getElementById('healthCsv');
  var healthPdf = document.getElementById('healthPdf');
  var printArea = document.getElementById('printArea');

  var vehicles = [
    { id: 'v1', name: 'Tata Ace (MH-12-1001)' },
    { id: 'v2', name: 'Ashok Leyland Dost (MH-14-2002)' },
    { id: 'v3', name: 'Eicher Pro (MH-01-3003)' },
    { id: 'v4', name: 'Mahindra Blazo (MH-02-5005)' },
    { id: 'v5', name: 'Bajaj Maxima (MH-43-4004)' }
  ];

  var drivers = [
    { id: 'd1', name: 'Raj Kumar' },
    { id: 'd2', name: 'Amit Sharma' },
    { id: 'd3', name: 'Priya Singh' },
    { id: 'd4', name: 'Vikram Patel' },
    { id: 'd5', name: 'Sneha Reddy' }
  ];

  function getFuelLogs() {
    try {
      var raw = localStorage.getItem(FUEL_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }

  function getMaintenanceCosts() {
    try {
      var raw = localStorage.getItem(MAINT_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }

  function getDriverProfiles() {
    try {
      var raw = localStorage.getItem(PROFILES_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch (e) {
      return {};
    }
  }

  function getRoiConfig() {
    try {
      var raw = localStorage.getItem(ROI_CONFIG_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch (e) {
      return {};
    }
  }

  function fuelEfficiencyPerVehicle() {
    var logs = getFuelLogs();
    var byId = {};
    vehicles.forEach(function (v) {
      byId[v.id] = { id: v.id, name: v.name, km: 0, liters: 0 };
    });
    logs.forEach(function (log) {
      if (!byId[log.vehicleId]) return;
      byId[log.vehicleId].liters += parseFloat(log.liters) || 0;
      if (log.distance != null && !isNaN(log.distance)) {
        byId[log.vehicleId].km += parseFloat(log.distance);
      }
    });
    return byId;
  }

  function totalsPerVehicle() {
    var fuel = getFuelLogs();
    var maint = getMaintenanceCosts();
    var byId = {};
    vehicles.forEach(function (v) {
      byId[v.id] = { id: v.id, name: v.name, fuel: 0, maintenance: 0 };
    });
    fuel.forEach(function (f) {
      byId[f.vehicleId].fuel += parseFloat(f.cost) || 0;
    });
    maint.forEach(function (m) {
      byId[m.vehicleId].maintenance += parseFloat(m.cost) || 0;
    });
    return byId;
  }

  function getRoiForVehicle(vId) {
    var config = getRoiConfig();
    var c = config[vId] || {};
    var acquisition = parseFloat(c.acquisitionCost) || 500000;
    var revenue = parseFloat(c.revenue) || 600000;
    return { acquisition: acquisition, revenue: revenue };
  }

  function formatNum(n) {
    return (Math.round(n * 100) / 100).toFixed(2);
  }

  function escapeHtml(s) {
    var div = document.createElement('div');
    div.textContent = s == null ? '' : String(s);
    return div.innerHTML;
  }

  function renderFuelEfficiency() {
    var byId = fuelEfficiencyPerVehicle();
    if (!fuelEfficiencyBody) return;
    fuelEfficiencyBody.innerHTML = vehicles.map(function (v) {
      var row = byId[v.id];
      var km = row.km;
      var liters = row.liters;
      var eff = liters > 0 && km > 0 ? (km / liters) : null;
      return '<tr>' +
        '<td>' + escapeHtml(v.id) + '</td>' +
        '<td>' + escapeHtml(v.name) + '</td>' +
        '<td>' + (km > 0 ? formatNum(km) : '—') + '</td>' +
        '<td>' + (liters > 0 ? formatNum(liters) : '—') + '</td>' +
        '<td>' + (eff != null ? formatNum(eff) + ' km/L' : '—') + '</td>' +
        '</tr>';
    }).join('');
  }

  function renderRoi() {
    var totals = totalsPerVehicle();
    if (!roiBody) return;
    roiBody.innerHTML = vehicles.map(function (v) {
      var row = totals[v.id];
      var roiConfig = getRoiForVehicle(v.id);
      var revenue = roiConfig.revenue;
      var acquisition = roiConfig.acquisition;
      var maint = row.maintenance;
      var fuel = row.fuel;
      var net = revenue - (maint + fuel);
      var roi = acquisition > 0 ? net / acquisition : 0;
      var roiClass = roi >= 0 ? '' : ' negative';
      return '<tr>' +
        '<td>' + escapeHtml(v.name) + '</td>' +
        '<td>' + formatNum(revenue) + '</td>' +
        '<td>' + formatNum(maint) + '</td>' +
        '<td>' + formatNum(fuel) + '</td>' +
        '<td>' + formatNum(acquisition) + '</td>' +
        '<td class="roi-cell' + roiClass + '">' + formatNum(roi) + '</td>' +
        '</tr>';
    }).join('');
  }

  function csvEscape(val) {
    var s = String(val == null ? '' : val);
    if (/[",\n\r]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
    return s;
  }

  function downloadCsv(filename, rows) {
    var csv = rows.map(function (row) { return row.map(csvEscape).join(','); }).join('\n');
    var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    var link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    link.click();
    URL.revokeObjectURL(link.href);
  }

  function printReport(title, html) {
    if (!printArea) return;
    printArea.innerHTML = '<h1 style="margin:0 0 1rem;">' + escapeHtml(title) + '</h1><p style="color:#64748b;margin:0 0 1rem;">Generated: ' + new Date().toISOString().slice(0, 10) + '</p>' + html;
    window.print();
  }

  function payrollCsvData() {
    var profiles = getDriverProfiles();
    var rows = [['Driver', 'Status', 'License expiry', 'Trip completion %', 'Safety score']];
    drivers.forEach(function (d) {
      var p = profiles[d.id] || {};
      rows.push([
        d.name,
        p.status === 'on_duty' ? 'On Duty' : p.status === 'off_duty' ? 'Off Duty' : p.status === 'suspended' ? 'Suspended' : '—',
        p.licenseExpiry || '—',
        p.tripCompletionRate != null ? p.tripCompletionRate : '—',
        p.safetyScore != null ? p.safetyScore : '—'
      ]);
    });
    return rows;
  }

  function healthCsvData() {
    var profiles = getDriverProfiles();
    var totals = totalsPerVehicle();
    var rows = [['Type', 'ID / Name', 'License expiry', 'Safety score', 'Status', 'Total fuel (₹)', 'Total maintenance (₹)']];
    drivers.forEach(function (d) {
      var p = profiles[d.id] || {};
      rows.push([
        'Driver',
        d.name,
        p.licenseExpiry || '—',
        p.safetyScore != null ? p.safetyScore : '—',
        p.status || '—',
        '—',
        '—'
      ]);
    });
    vehicles.forEach(function (v) {
      var row = totals[v.id];
      rows.push([
        'Vehicle',
        v.name,
        '—',
        '—',
        '—',
        formatNum(row.fuel),
        formatNum(row.maintenance)
      ]);
    });
    return rows;
  }

  function payrollHtml() {
    var profiles = getDriverProfiles();
    var rows = drivers.map(function (d) {
      var p = profiles[d.id] || {};
      var status = p.status === 'on_duty' ? 'On Duty' : p.status === 'off_duty' ? 'Off Duty' : p.status === 'suspended' ? 'Suspended' : '—';
      return '<tr><td>' + escapeHtml(d.name) + '</td><td>' + status + '</td><td>' + escapeHtml(p.licenseExpiry || '—') + '</td><td>' + (p.tripCompletionRate != null ? p.tripCompletionRate + '%' : '—') + '</td><td>' + (p.safetyScore != null ? p.safetyScore : '—') + '</td></tr>';
    }).join('');
    return '<table style="width:100%;border-collapse:collapse;"><thead><tr><th style="text-align:left;padding:6px;border:1px solid #e2e8f0;">Driver</th><th style="text-align:left;padding:6px;border:1px solid #e2e8f0;">Status</th><th style="text-align:left;padding:6px;border:1px solid #e2e8f0;">License expiry</th><th style="text-align:left;padding:6px;border:1px solid #e2e8f0;">Completion %</th><th style="text-align:left;padding:6px;border:1px solid #e2e8f0;">Safety score</th></tr></thead><tbody>' + rows + '</tbody></table>';
  }

  function healthHtml() {
    var profiles = getDriverProfiles();
    var totals = totalsPerVehicle();
    var driverRows = drivers.map(function (d) {
      var p = profiles[d.id] || {};
      return '<tr><td>Driver</td><td>' + escapeHtml(d.name) + '</td><td>' + escapeHtml(p.licenseExpiry || '—') + '</td><td>' + (p.safetyScore != null ? p.safetyScore : '—') + '</td><td>' + escapeHtml(p.status || '—') + '</td><td>—</td><td>—</td></tr>';
    }).join('');
    var vehicleRows = vehicles.map(function (v) {
      var row = totals[v.id];
      return '<tr><td>Vehicle</td><td>' + escapeHtml(v.name) + '</td><td>—</td><td>—</td><td>—</td><td>' + formatNum(row.fuel) + '</td><td>' + formatNum(row.maintenance) + '</td></tr>';
    }).join('');
    return '<table style="width:100%;border-collapse:collapse;"><thead><tr><th style="text-align:left;padding:6px;border:1px solid #e2e8f0;">Type</th><th style="text-align:left;padding:6px;border:1px solid #e2e8f0;">Name</th><th style="text-align:left;padding:6px;border:1px solid #e2e8f0;">License expiry</th><th style="text-align:left;padding:6px;border:1px solid #e2e8f0;">Safety score</th><th style="text-align:left;padding:6px;border:1px solid #e2e8f0;">Status</th><th style="text-align:left;padding:6px;border:1px solid #e2e8f0;">Fuel (₹)</th><th style="text-align:left;padding:6px;border:1px solid #e2e8f0;">Maintenance (₹)</th></tr></thead><tbody>' + driverRows + vehicleRows + '</tbody></table>';
  }

  if (payrollCsv) {
    payrollCsv.addEventListener('click', function () {
      var month = new Date().toISOString().slice(0, 7);
      downloadCsv('monthly-payroll-' + month + '.csv', payrollCsvData());
    });
  }
  if (payrollPdf) {
    payrollPdf.addEventListener('click', function () {
      printReport('Monthly Payroll Report', payrollHtml());
    });
  }
  if (healthCsv) {
    healthCsv.addEventListener('click', function () {
      var month = new Date().toISOString().slice(0, 7);
      downloadCsv('health-audits-' + month + '.csv', healthCsvData());
    });
  }
  if (healthPdf) {
    healthPdf.addEventListener('click', function () {
      printReport('Health Audits Report', healthHtml());
    });
  }

  renderFuelEfficiency();
  renderRoi();
})();
