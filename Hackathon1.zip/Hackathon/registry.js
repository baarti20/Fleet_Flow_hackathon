(function () {
  'use strict';

  var tableBody = document.getElementById('registryTableBody');
  var registryCount = document.getElementById('registryCount');
  var btnAdd = document.getElementById('btnAddVehicle');
  var modal = document.getElementById('vehicleModal');
  var modalBackdrop = document.getElementById('modalBackdrop');
  var closeModal = document.getElementById('closeModal');
  var modalTitle = document.getElementById('modalTitle');
  var form = document.getElementById('vehicleForm');
  var vehicleId = document.getElementById('vehicleId');
  var vehicleName = document.getElementById('vehicleName');
  var vehiclePlate = document.getElementById('vehiclePlate');
  var vehicleCapacity = document.getElementById('vehicleCapacity');
  var vehicleOdometer = document.getElementById('vehicleOdometer');
  var plateError = document.getElementById('plateError');
  var btnCancel = document.getElementById('btnCancel');
  var btnSubmit = document.getElementById('btnSubmit');

  var nextId = 6;
  var vehicles = [
    { id: 1, name: 'Tata Ace', licensePlate: 'MH-12-AB-1001', maxLoadKg: 750, odometer: 45000, outOfService: false },
    { id: 2, name: 'Ashok Leyland Dost', licensePlate: 'MH-14-CD-2002', maxLoadKg: 1500, odometer: 82000, outOfService: false },
    { id: 3, name: 'Eicher Pro', licensePlate: 'MH-01-EF-3003', maxLoadKg: 2500, odometer: 120000, outOfService: true },
    { id: 4, name: 'Bajaj Maxima C', licensePlate: 'MH-43-GH-4004', maxLoadKg: 300, odometer: 28000, outOfService: false },
    { id: 5, name: 'Mahindra Blazo', licensePlate: 'MH-02-IJ-5005', maxLoadKg: 5000, odometer: 95000, outOfService: false }
  ];

  function escapeHtml(s) {
    var div = document.createElement('div');
    div.textContent = s;
    return div.innerHTML;
  }

  function openModal(editVehicle) {
    vehicleId.value = editVehicle ? editVehicle.id : '';
    vehicleName.value = editVehicle ? editVehicle.name : '';
    vehiclePlate.value = editVehicle ? editVehicle.licensePlate : '';
    vehicleCapacity.value = editVehicle ? String(editVehicle.maxLoadKg) : '';
    vehicleOdometer.value = editVehicle ? String(editVehicle.odometer) : '';
    plateError.textContent = '';
    modalTitle.textContent = editVehicle ? 'Edit vehicle' : 'Add vehicle';
    modal.hidden = false;
    if (vehicleName) vehicleName.focus();
  }

  function closeModalFn() {
    modal.hidden = true;
  }

  function isPlateUnique(plate, excludeId) {
    plate = (plate || '').trim().toUpperCase();
    for (var i = 0; i < vehicles.length; i++) {
      if (vehicles[i].id === excludeId) continue;
      if (vehicles[i].licensePlate.toUpperCase() === plate) return false;
    }
    return true;
  }

  function saveVehicle(e) {
    e.preventDefault();
    var id = vehicleId.value ? parseInt(vehicleId.value, 10) : null;
    var name = (vehicleName.value || '').trim();
    var plate = (vehiclePlate.value || '').trim();
    var maxLoadKg = parseInt(vehicleCapacity.value, 10);
    var odometer = parseInt(vehicleOdometer.value, 10);
    plateError.textContent = '';

    if (!plate) {
      plateError.textContent = 'License plate is required.';
      return;
    }
    if (!isPlateUnique(plate, id)) {
      plateError.textContent = 'This license plate is already in use.';
      return;
    }
    if (isNaN(maxLoadKg) || maxLoadKg < 1) {
      plateError.textContent = '';
      return;
    }
    if (isNaN(odometer) || odometer < 0) return;

    if (id) {
      var idx = vehicles.findIndex(function (v) { return v.id === id; });
      if (idx !== -1) {
        vehicles[idx].name = name;
        vehicles[idx].licensePlate = plate;
        vehicles[idx].maxLoadKg = maxLoadKg;
        vehicles[idx].odometer = odometer;
      }
    } else {
      vehicles.push({
        id: nextId++,
        name: name,
        licensePlate: plate,
        maxLoadKg: maxLoadKg,
        odometer: odometer,
        outOfService: false
      });
    }
    closeModalFn();
    render();
  }

  function deleteVehicle(id) {
    if (!confirm('Remove this vehicle from the registry?')) return;
    vehicles = vehicles.filter(function (v) { return v.id !== id; });
    render();
  }

  function toggleOutOfService(id) {
    var v = vehicles.find(function (x) { return x.id === id; });
    if (v) {
      v.outOfService = !v.outOfService;
      render();
    }
  }

  function render() {
    if (!tableBody) return;
    tableBody.innerHTML = vehicles.map(function (v, idx) {
      var rowClass = v.outOfService ? ' class="out-of-service"' : '';
      var toggleClass = v.outOfService ? ' toggle on' : ' toggle';
      var label = v.outOfService ? 'Out of Service' : 'Idle';
      return '<tr' + rowClass + '>' +
        '<td>' + (idx + 1) + '</td>' +
        '<td>' + escapeHtml(v.licensePlate) + '</td>' +
        '<td>' + escapeHtml(v.name) + '</td>' +
        '<td>' + escapeHtml(String(v.maxLoadKg)) + ' kg</td>' +
        '<td>' + escapeHtml(String(v.odometer)) + '</td>' +
        '<td><div class="toggle-wrap"><button type="button" class="' + toggleClass + '" data-id="' + v.id + '" aria-pressed="' + v.outOfService + '" title="Out of Service"></button><span class="toggle-label">' + label + '</span></div></td>' +
        '<td><div class="cell-actions"><button type="button" class="btn-cell btn-edit" data-id="' + v.id + '">Edit</button><button type="button" class="btn-cell btn-delete" data-id="' + v.id + '">Delete</button></div></td>' +
        '</tr>';
    }).join('');

    if (registryCount) registryCount.textContent = vehicles.length + ' vehicle' + (vehicles.length === 1 ? '' : 's');

    tableBody.querySelectorAll('.toggle').forEach(function (el) {
      el.addEventListener('click', function () {
        var id = parseInt(el.getAttribute('data-id'), 10);
        toggleOutOfService(id);
      });
    });
    tableBody.querySelectorAll('.btn-edit').forEach(function (el) {
      el.addEventListener('click', function () {
        var id = parseInt(el.getAttribute('data-id'), 10);
        var v = vehicles.find(function (x) { return x.id === id; });
        if (v) openModal(v);
      });
    });
    tableBody.querySelectorAll('.btn-delete').forEach(function (el) {
      el.addEventListener('click', function () {
        var id = parseInt(el.getAttribute('data-id'), 10);
        deleteVehicle(id);
      });
    });
  }

  if (btnAdd) btnAdd.addEventListener('click', function () { openModal(null); });
  if (closeModal) closeModal.addEventListener('click', closeModalFn);
  if (modalBackdrop) modalBackdrop.addEventListener('click', closeModalFn);
  if (btnCancel) btnCancel.addEventListener('click', closeModalFn);
  if (form) form.addEventListener('submit', saveVehicle);

  render();
})();
