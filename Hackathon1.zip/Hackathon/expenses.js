(function () {
  'use strict';

  var FUEL_KEY = 'portal_fuel_logs';
  var MAINT_COST_KEY = 'portal_maintenance_costs';

  var fuelForm = document.getElementById('fuelForm');
  var fuelVehicle = document.getElementById('fuelVehicle');
  var fuelLiters = document.getElementById('fuelLiters');
  var fuelCost = document.getElementById('fuelCost');
  var fuelDistance = document.getElementById('fuelDistance');
  var fuelDate = document.getElementById('fuelDate');
  var maintenanceForm = document.getElementById('maintenanceForm');
  var maintVehicle = document.getElementById('maintVehicle');
  var maintCost = document.getElementById('maintCost');
  var maintDate = document.getElementById('maintDate');
  var maintNotes = document.getElementById('maintNotes');
  var summaryTableBody = document.getElementById('summaryTableBody');
  var entriesTableBody = document.getElementById('entriesTableBody');

  var vehicles = [
    { id: 'v1', name: 'Tata Ace (MH-12-1001)' },
    { id: 'v2', name: 'Ashok Leyland Dost (MH-14-2002)' },
    { id: 'v3', name: 'Eicher Pro (MH-01-3003)' },
    { id: 'v4', name: 'Mahindra Blazo (MH-02-5005)' },
    { id: 'v5', name: 'Bajaj Maxima (MH-43-4004)' }
  ];

  function getFuelLogs() {
    try {
      var raw = localStorage.getItem(FUEL_KEY);
      if (!raw) return [];
      var arr = JSON.parse(raw);
      return Array.isArray(arr) ? arr : [];
    } catch (e) {
      return [];
    }
  }

  function setFuelLogs(logs) {
    try {
      localStorage.setItem(FUEL_KEY, JSON.stringify(logs));
    } catch (e) {}
  }

  function getMaintenanceCosts() {
    try {
      var raw = localStorage.getItem(MAINT_COST_KEY);
      if (!raw) return [];
      var arr = JSON.parse(raw);
      return Array.isArray(arr) ? arr : [];
    } catch (e) {
      return [];
    }
  }

  function setMaintenanceCosts(costs) {
    try {
      localStorage.setItem(MAINT_COST_KEY, JSON.stringify(costs));
    } catch (e) {}
  }

  function getVehicleName(id) {
    for (var i = 0; i < vehicles.length; i++) {
      if (vehicles[i].id === id) return vehicles[i].name;
    }
    return id;
  }

  function fillSelect(selectEl) {
    if (!selectEl) return;
    selectEl.innerHTML = '<option value="">Select vehicle...</option>';
    for (var i = 0; i < vehicles.length; i++) {
      var v = vehicles[i];
      var opt = document.createElement('option');
      opt.value = v.id;
      opt.textContent = v.name;
      selectEl.appendChild(opt);
    }
  }

  function computeTotalsPerVehicle() {
    var fuel = getFuelLogs();
    var maint = getMaintenanceCosts();
    var byId = {};
    for (var i = 0; i < vehicles.length; i++) {
      var v = vehicles[i];
      byId[v.id] = { id: v.id, name: v.name, fuel: 0, maintenance: 0 };
    }
    for (var j = 0; j < fuel.length; j++) {
      var f = fuel[j];
      var cost = parseFloat(f.cost) || 0;
      if (byId[f.vehicleId]) byId[f.vehicleId].fuel += cost;
    }
    for (var k = 0; k < maint.length; k++) {
      var m = maint[k];
      var cost = parseFloat(m.cost) || 0;
      if (byId[m.vehicleId]) byId[m.vehicleId].maintenance += cost;
    }
    return byId;
  }

  function formatMoney(n) {
    return (Math.round(n * 100) / 100).toFixed(2);
  }

  function escapeHtml(s) {
    var div = document.createElement('div');
    div.textContent = s == null ? '' : String(s);
    return div.innerHTML;
  }

  function renderSummary() {
    var byId = computeTotalsPerVehicle();
    if (!summaryTableBody) return;
    var rows = [];
    for (var i = 0; i < vehicles.length; i++) {
      var v = vehicles[i];
      var row = byId[v.id] || { id: v.id, name: v.name, fuel: 0, maintenance: 0 };
      var total = row.fuel + row.maintenance;
      rows.push(
        '<tr>' +
          '<td>' + escapeHtml(row.id) + '</td>' +
          '<td>' + escapeHtml(row.name) + '</td>' +
          '<td>' + formatMoney(row.fuel) + '</td>' +
          '<td>' + formatMoney(row.maintenance) + '</td>' +
          '<td class="total-cell">' + formatMoney(total) + '</td>' +
        '</tr>'
      );
    }
    summaryTableBody.innerHTML = rows.join('');
  }

  function renderEntries() {
    var fuel = getFuelLogs();
    var maint = getMaintenanceCosts();
    var combined = [];
    fuel.forEach(function (f) {
      combined.push({ type: 'fuel', date: f.date, vehicleName: f.vehicleName, liters: f.liters, cost: f.cost });
    });
    maint.forEach(function (m) {
      combined.push({ type: 'maintenance', date: m.date, vehicleName: m.vehicleName, liters: '—', cost: m.cost });
    });
    combined.sort(function (a, b) {
      return (b.date || '').localeCompare(a.date || '');
    });
    var recent = combined.slice(0, 20);
    if (!entriesTableBody) return;
    entriesTableBody.innerHTML = recent.length === 0
      ? '<tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:2rem;">No entries yet. Add fuel or maintenance above.</td></tr>'
      : recent.map(function (e) {
          var typeClass = e.type === 'fuel' ? 'fuel' : 'maintenance';
          var typeLabel = e.type === 'fuel' ? 'Fuel' : 'Maintenance';
          return '<tr>' +
            '<td><span class="type-pill ' + typeClass + '">' + typeLabel + '</span></td>' +
            '<td>' + escapeHtml(e.vehicleName) + '</td>' +
            '<td>' + (e.liters !== undefined ? escapeHtml(String(e.liters)) : '—') + '</td>' +
            '<td>' + formatMoney(parseFloat(e.cost) || 0) + '</td>' +
            '<td>' + escapeHtml(e.date) + '</td>' +
            '</tr>';
        }).join('');
  }

  var nextFuelId = 1;
  var nextMaintId = 1;

  fuelForm.addEventListener('submit', function (e) {
    e.preventDefault();
    var vehicleId = (fuelVehicle && fuelVehicle.value) || '';
    var liters = parseFloat(fuelLiters.value) || 0;
    var cost = parseFloat(fuelCost.value) || 0;
    var distance = (fuelDistance && fuelDistance.value) !== '' ? parseFloat(fuelDistance.value) : null;
    var date = (fuelDate && fuelDate.value) || '';
    if (!vehicleId || !date) return;
    var logs = getFuelLogs();
    if (logs.length > 0) {
      var maxId = 0;
      logs.forEach(function (l) { if (l.id > maxId) maxId = l.id; });
      nextFuelId = maxId + 1;
    }
    logs.push({
      id: nextFuelId++,
      vehicleId: vehicleId,
      vehicleName: getVehicleName(vehicleId),
      liters: liters,
      cost: cost,
      distance: distance,
      date: date
    });
    setFuelLogs(logs);
    fuelForm.reset();
    if (fuelDate) fuelDate.value = new Date().toISOString().slice(0, 10);
    renderSummary();
    renderEntries();
  });

  maintenanceForm.addEventListener('submit', function (e) {
    e.preventDefault();
    var vehicleId = (maintVehicle && maintVehicle.value) || '';
    var cost = parseFloat(maintCost.value) || 0;
    var date = (maintDate && maintDate.value) || '';
    var notes = (maintNotes && maintNotes.value) || '';
    if (!vehicleId || !date) return;
    var costs = getMaintenanceCosts();
    if (costs.length > 0) {
      var maxId = 0;
      costs.forEach(function (c) { if (c.id > maxId) maxId = c.id; });
      nextMaintId = maxId + 1;
    }
    costs.push({
      id: nextMaintId++,
      vehicleId: vehicleId,
      vehicleName: getVehicleName(vehicleId),
      cost: cost,
      date: date,
      notes: notes
    });
    setMaintenanceCosts(costs);
    maintenanceForm.reset();
    if (maintDate) maintDate.value = new Date().toISOString().slice(0, 10);
    renderSummary();
    renderEntries();
  });

  fillSelect(fuelVehicle);
  fillSelect(maintVehicle);
  if (fuelDate) fuelDate.value = new Date().toISOString().slice(0, 10);
  if (maintDate) maintDate.value = new Date().toISOString().slice(0, 10);
  renderSummary();
  renderEntries();
})();
