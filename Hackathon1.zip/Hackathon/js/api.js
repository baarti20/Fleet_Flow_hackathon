/**
 * FleetFlow API Client
 * Shared fetch helpers - uses /api when running with backend
 */
(function (global) {
  'use strict';

  var BASE = '';

  function getBase() {
    if (typeof window === 'undefined' || !window.location) return '';
    var origin = window.location.origin;
    var protocol = window.location.protocol || '';
    if (origin && origin !== 'null' && protocol !== 'file:') return origin;
    return 'http://localhost:3000';
  }

  function fetchApi(method, path, body) {
    var url = getBase() + path;
    var opts = { method: method, headers: { 'Content-Type': 'application/json' } };
    if (body) opts.body = JSON.stringify(body);
    return fetch(url, opts).then(function (r) {
      if (r.status === 204) return null;
      var j = r.json();
      if (!r.ok) return j.then(function (e) { throw new Error(e.error || 'Request failed'); });
      return j;
    });
  }

  var api = {
    vehicles: {
      list: function () { return fetchApi('GET', '/api/vehicles'); },
      create: function (data) { return fetchApi('POST', '/api/vehicles', data); },
      update: function (id, data) { return fetchApi('PUT', '/api/vehicles/' + encodeURIComponent(id), data); },
      patch: function (id, data) { return fetchApi('PATCH', '/api/vehicles/' + encodeURIComponent(id), data); },
      delete: function (id) { return fetchApi('DELETE', '/api/vehicles/' + encodeURIComponent(id)); }
    },
    drivers: {
      list: function () { return fetchApi('GET', '/api/drivers'); }
    },
    driverProfiles: {
      list: function () { return fetchApi('GET', '/api/driver-profiles'); },
      update: function (driverId, data) { return fetchApi('PUT', '/api/driver-profiles/' + encodeURIComponent(driverId), data); }
    },
    trips: {
      list: function () { return fetchApi('GET', '/api/trips'); },
      create: function (data) { return fetchApi('POST', '/api/trips', data); },
      patch: function (id, data) { return fetchApi('PATCH', '/api/trips/' + id, data); }
    },
    vehiclesInShop: {
      list: function () { return fetchApi('GET', '/api/vehicles-in-shop'); },
      add: function (vehicleId) { return fetchApi('POST', '/api/vehicles-in-shop', { vehicleId: vehicleId }); },
      remove: function (vehicleId) { return fetchApi('DELETE', '/api/vehicles-in-shop/' + encodeURIComponent(vehicleId)); }
    },
    serviceLogs: {
      list: function () { return fetchApi('GET', '/api/service-logs'); },
      create: function (data) { return fetchApi('POST', '/api/service-logs', data); },
      complete: function (id) { return fetchApi('PATCH', '/api/service-logs/' + id, { status: 'closed' }); }
    },
    fuelLogs: {
      list: function () { return fetchApi('GET', '/api/fuel-logs'); },
      create: function (data) { return fetchApi('POST', '/api/fuel-logs', data); }
    },
    maintenanceCosts: {
      list: function () { return fetchApi('GET', '/api/maintenance-costs'); },
      create: function (data) { return fetchApi('POST', '/api/maintenance-costs', data); }
    },
    vehicleRoiConfig: {
      list: function () { return fetchApi('GET', '/api/vehicle-roi-config'); },
      update: function (vehicleId, data) { return fetchApi('PUT', '/api/vehicle-roi-config/' + encodeURIComponent(vehicleId), data); }
    },
    fleet: {
      list: function () { return fetchApi('GET', '/api/fleet'); }
    },
    auth: {
      register: function (data) { return fetchApi('POST', '/api/auth/register', data); },
      login: function (data) { return fetchApi('POST', '/api/auth/login', data); }
    }
  };

  global.FleetFlowApi = api;
})(typeof window !== 'undefined' ? window : this);
