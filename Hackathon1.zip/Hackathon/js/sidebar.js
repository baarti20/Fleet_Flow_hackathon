(function () {
  function init() {
    var shell = document.querySelector('.app-shell');
    var toggle = document.querySelector('.sidebar-toggle');
    var overlay = document.querySelector('.sidebar-overlay');
    if (!shell || !toggle) return;

    function open() {
      shell.classList.add('sidebar-open');
      if (overlay) overlay.setAttribute('aria-hidden', 'false');
      toggle.setAttribute('aria-label', 'Close menu');
    }
    function close() {
      shell.classList.remove('sidebar-open');
      if (overlay) overlay.setAttribute('aria-hidden', 'true');
      toggle.setAttribute('aria-label', 'Open menu');
    }
    function toggleSidebar() {
      shell.classList.toggle('sidebar-open');
      var isOpen = shell.classList.contains('sidebar-open');
      if (overlay) overlay.setAttribute('aria-hidden', isOpen ? 'false' : 'true');
      toggle.setAttribute('aria-label', isOpen ? 'Close menu' : 'Open menu');
    }

    toggle.addEventListener('click', toggleSidebar);
    if (overlay) overlay.addEventListener('click', close);

    document.querySelectorAll('.nav-sidebar .nav-item').forEach(function (link) {
      link.addEventListener('click', close);
    });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
