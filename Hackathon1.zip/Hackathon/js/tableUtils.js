/**
 * FleetFlow Table Utils
 * Shared module for search, filter, sort, and group on table views.
 * Each page calls FleetFlowTableUtils.init(config) with page-specific config.
 */
(function (global) {
  'use strict';

  var TABLE_UTILS_DROPDOWN_ID = 'ff-table-utils-dropdown';
  var GROUP_HEADER_CLASS = 'ff-group-header';

  function getRows(tbody) {
    if (!tbody) return [];
    var rows = Array.prototype.slice.call(tbody.querySelectorAll('tr'));
    return rows.filter(function (r) {
      if (r.classList && r.classList.contains(GROUP_HEADER_CLASS)) return false;
      var firstCell = r.querySelector('td');
      return firstCell && !firstCell.hasAttribute('colspan');
    });
  }

  function getCellText(cell) {
    if (!cell) return '';
    var text = (cell.textContent || '').trim().toLowerCase();
    return text;
  }

  function getRowText(row, columnIndices) {
    var cells = row.querySelectorAll('td');
    var parts = [];
    for (var i = 0; i < columnIndices.length; i++) {
      var idx = columnIndices[i];
      if (cells[idx]) parts.push(getCellText(cells[idx]));
    }
    return parts.join(' ');
  }

  /**
   * searchTable - Filters visible rows by search term across specified columns.
   * Rows that match (case-insensitive, any column) are shown; others hidden.
   */
  function searchTable(tbody, term, searchColumns) {
    var rows = getRows(tbody);
    term = (term || '').trim().toLowerCase();
    if (!searchColumns || searchColumns.length === 0) {
      rows.forEach(function (row) { row.style.display = ''; });
      return;
    }
    rows.forEach(function (row) {
      if (!term) {
        row.style.display = '';
        return;
      }
      var rowText = getRowText(row, searchColumns);
      var match = rowText.indexOf(term) !== -1;
      row.style.display = match ? '' : 'none';
    });
  }

  /**
   * filterTable - Applies filter criteria to rows.
   * Rows must match ALL criteria. Works in combination with search.
   */
  function filterTable(tbody, filterCriteria) {
    var rows = getRows(tbody);
    var hasFilter = false;
    for (var k in filterCriteria) {
      if (filterCriteria[k]) { hasFilter = true; break; }
    }
    if (!hasFilter) return;
    rows.forEach(function (row) {
      if (row.style.display === 'none') return;
      var cells = row.querySelectorAll('td');
      var pass = true;
      for (var colIdx in filterCriteria) {
        var val = filterCriteria[colIdx];
        if (!val) continue;
        var cell = cells[parseInt(colIdx, 10)];
        var cellText = getCellText(cell);
        pass = cellText.indexOf(String(val).toLowerCase()) !== -1;
        if (!pass) break;
      }
      row.style.display = pass ? '' : 'none';
    });
  }

  /**
   * sortTable - Sorts rows by column index, ascending or descending.
   * Skips group headers. Uses natural sort for numbers when possible.
   */
  function sortTable(tbody, columnIndex, ascending) {
    var rows = getRows(tbody);
    var visible = rows.filter(function (r) { return r.style.display !== 'none'; });
    var parseVal = function (text) {
      var n = parseFloat(String(text).replace(/[^\d.-]/g, ''));
      return !isNaN(n) ? n : text;
    };
    visible.sort(function (a, b) {
      var aCell = a.querySelectorAll('td')[columnIndex];
      var bCell = b.querySelectorAll('td')[columnIndex];
      var aText = getCellText(aCell);
      var bText = getCellText(bCell);
      var aVal = parseVal(aText);
      var bVal = parseVal(bText);
      var cmp = 0;
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        cmp = aVal - bVal;
      } else {
        cmp = String(aText).localeCompare(String(bText));
      }
      return ascending ? cmp : -cmp;
    });
    var fragment = document.createDocumentFragment();
    rows.forEach(function (r) {
      if (r.style.display === 'none') fragment.appendChild(r);
    });
    visible.forEach(function (r) {
      fragment.appendChild(r);
    });
    tbody.innerHTML = '';
    tbody.appendChild(fragment);
  }

  /**
   * groupTable - Groups rows by column value, inserting group header rows.
   * Pass columnIndex to group, or null to ungroup.
   */
  function groupTable(tbody, columnIndex, columns) {
    var rows = getRows(tbody);
    var groupHeaders = tbody.querySelectorAll('tr.' + GROUP_HEADER_CLASS);
    groupHeaders.forEach(function (h) { h.remove(); });

    if (columnIndex == null) return;

    var groups = {};
    var hidden = [];
    rows.forEach(function (row) {
      if (row.style.display === 'none') {
        hidden.push(row);
        return;
      }
      var cells = row.querySelectorAll('td');
      var cell = cells[columnIndex];
      var val = getCellText(cell) || '(empty)';
      if (!groups[val]) groups[val] = [];
      groups[val].push(row);
    });

    var labels = Object.keys(groups).sort();
    var fragment = document.createDocumentFragment();
    var colLabel = (columns && columns[columnIndex]) ? columns[columnIndex].label : 'Column ' + columnIndex;
    labels.forEach(function (label) {
      var header = document.createElement('tr');
      header.className = GROUP_HEADER_CLASS;
      header.innerHTML = '<td colspan="99" class="' + GROUP_HEADER_CLASS + '-cell">' + colLabel + ': ' + label + '</td>';
      fragment.appendChild(header);
      groups[label].forEach(function (r) { fragment.appendChild(r); });
    });
    hidden.forEach(function (r) { fragment.appendChild(r); });
    tbody.innerHTML = '';
    tbody.appendChild(fragment);
  }

  function updateFooter(footerId, count, template) {
    var el = document.getElementById(footerId);
    if (!el) return;
    template = template || 'Showing {n}';
    el.textContent = template.replace(/\{n\}/g, count);
  }

  function countVisible(tbody) {
    var rows = getRows(tbody);
    return rows.filter(function (r) { return r.style.display !== 'none'; }).length;
  }

  function createDropdown(id, content, anchor) {
    var existing = document.getElementById(id);
    if (existing) existing.remove();
    var div = document.createElement('div');
    div.id = id;
    div.className = 'ff-utils-dropdown';
    div.innerHTML = content;
    div.addEventListener('click', function (e) { e.stopPropagation(); });
    document.body.appendChild(div);
    var rect = anchor.getBoundingClientRect();
    div.style.top = (rect.bottom + 4) + 'px';
    div.style.left = rect.left + 'px';
    return div;
  }

  function closeDropdown() {
    var el = document.getElementById(TABLE_UTILS_DROPDOWN_ID);
    if (el) el.remove();
  }

  function toggleActive(btn, active) {
    if (!btn) return;
    if (active) btn.classList.add('active'); else btn.classList.remove('active');
  }

  function init(config) {
    var searchBar = document.querySelector('.search-bar');
    var barActions = document.querySelector('.bar-actions');
    var btnGroup = barActions ? barActions.children[0] : null;
    var btnFilter = barActions ? barActions.children[1] : null;
    var btnSort = barActions ? barActions.children[2] : null;

    var tbodyIds = config.tbodyIds || [config.tbodyId];
    if (config.tbodyId && tbodyIds.length === 0) tbodyIds = [config.tbodyId];

    var searchColumns = config.searchColumns || [];
    var sortColumns = config.sortColumns || [];
    var groupColumns = config.groupColumns || [];
    var filterOptions = config.filterOptions || [];
    var footerId = config.footerId;
    var footerTemplate = config.footerTemplate || 'Showing {n}';
    var onRefresh = config.onRefresh || function () {};

    var state = {
      searchTerm: '',
      filterCriteria: {},
      sortColumn: null,
      sortAsc: true,
      groupBy: null
    };

    function getTbodies() {
      return tbodyIds.map(function (id) { return document.getElementById(id); }).filter(Boolean);
    }

    function applyAll() {
      var q = state.searchTerm;
      getTbodies().forEach(function (tb) {
        searchTable(tb, q, searchColumns);
        filterTable(tb, state.filterCriteria);
        if (state.sortColumn != null) {
          sortTable(tb, state.sortColumn, state.sortAsc);
        }
        if (state.groupBy != null) {
          groupTable(tb, state.groupBy, groupColumns);
        }
      });
      var total = getTbodies().reduce(function (sum, tb) { return sum + countVisible(tb); }, 0);
      if (footerId) updateFooter(footerId, total, footerTemplate);
      onRefresh();
    }

    if (searchBar) {
      var searchTimeout;
      function applySearch() {
        state.searchTerm = (searchBar.value || '').trim().toLowerCase();
        applyAll();
      }
      function onSearchInput() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(applySearch, 100);
      }
      searchBar.addEventListener('input', onSearchInput);
      searchBar.addEventListener('change', applySearch);
      searchBar.addEventListener('search', applySearch);
      searchBar.addEventListener('keyup', function (e) {
        if (e.key === 'Escape') {
          searchBar.value = '';
          state.searchTerm = '';
          applyAll();
          searchBar.blur();
        } else {
          onSearchInput();
        }
      });
      searchBar.setAttribute('autocomplete', 'off');
    }

    if (btnGroup && groupColumns.length) {
      btnGroup.addEventListener('click', function (e) {
        e.stopPropagation();
        var open = document.getElementById(TABLE_UTILS_DROPDOWN_ID);
        if (open) { closeDropdown(); return; }
        var html = '<div class="ff-dropdown-title">Group by</div>';
        html += '<button type="button" class="ff-dropdown-item" data-action="group" data-col="-1">None</button>';
        groupColumns.forEach(function (c) {
          html += '<button type="button" class="ff-dropdown-item" data-action="group" data-col="' + c.index + '">' + (c.label || 'Column ' + c.index) + '</button>';
        });
        var dd = createDropdown(TABLE_UTILS_DROPDOWN_ID, html, btnGroup);
        toggleActive(btnGroup, true);
        dd.querySelectorAll('.ff-dropdown-item').forEach(function (btn) {
          btn.addEventListener('click', function (e) {
            e.stopPropagation();
            var col = parseInt(btn.getAttribute('data-col'), 10);
            state.groupBy = col >= 0 ? col : null;
            getTbodies().forEach(function (tb) {
              groupTable(tb, col >= 0 ? col : null, groupColumns);
            });
            applyAll();
            toggleActive(btnGroup, state.groupBy != null);
            closeDropdown();
          });
        });
      });
    }

    if (btnFilter && filterOptions.length) {
      btnFilter.addEventListener('click', function (e) {
        e.stopPropagation();
        var open = document.getElementById(TABLE_UTILS_DROPDOWN_ID);
        if (open) { closeDropdown(); return; }
        var html = '<div class="ff-dropdown-title">Filter</div>';
        filterOptions.forEach(function (opt) {
          html += '<div class="ff-filter-row"><label>' + (opt.label || '') + '</label><select class="ff-filter-select" data-col="' + opt.columnIndex + '">';
          html += '<option value="">All</option>';
          (opt.values || []).forEach(function (v) {
            var sel = (state.filterCriteria[opt.columnIndex] === v) ? ' selected' : '';
            html += '<option value="' + v + '"' + sel + '>' + v + '</option>';
          });
          html += '</select></div>';
        });
        html += '<button type="button" class="ff-dropdown-apply">Apply</button>';
        var dd = createDropdown(TABLE_UTILS_DROPDOWN_ID, html, btnFilter);
        toggleActive(btnFilter, Object.keys(state.filterCriteria).some(function (k) { return state.filterCriteria[k]; }));
        dd.querySelector('.ff-dropdown-apply').addEventListener('click', function (e) {
          e.stopPropagation();
          state.filterCriteria = {};
          dd.querySelectorAll('.ff-filter-select').forEach(function (sel) {
            var col = parseInt(sel.getAttribute('data-col'), 10);
            var val = sel.value || '';
            if (val) state.filterCriteria[col] = val;
          });
          getTbodies().forEach(function (tb) {
            filterTable(tb, state.filterCriteria);
          });
          applyAll();
          toggleActive(btnFilter, Object.keys(state.filterCriteria).length > 0);
          closeDropdown();
        });
      });
    }

    if (btnSort && sortColumns.length) {
      btnSort.addEventListener('click', function (e) {
        e.stopPropagation();
        var open = document.getElementById(TABLE_UTILS_DROPDOWN_ID);
        if (open) { closeDropdown(); return; }
        var html = '<div class="ff-dropdown-title">Sort by</div>';
        sortColumns.forEach(function (c) {
          var idx = c.index;
          var label = c.label || 'Column ' + idx;
          var ascClass = (state.sortColumn === idx && state.sortAsc) ? ' active' : '';
          var descClass = (state.sortColumn === idx && !state.sortAsc) ? ' active' : '';
          html += '<div class="ff-sort-row">';
          html += '<span class="ff-sort-label">' + label + '</span>';
          html += '<button type="button" class="ff-sort-btn' + ascClass + '" data-col="' + idx + '" data-asc="1">↑</button>';
          html += '<button type="button" class="ff-sort-btn' + descClass + '" data-col="' + idx + '" data-asc="0">↓</button>';
          html += '</div>';
        });
        var dd = createDropdown(TABLE_UTILS_DROPDOWN_ID, html, btnSort);
        toggleActive(btnSort, state.sortColumn != null);
        dd.querySelectorAll('.ff-sort-btn').forEach(function (btn) {
          btn.addEventListener('click', function (e) {
            e.stopPropagation();
            state.sortColumn = parseInt(btn.getAttribute('data-col'), 10);
            state.sortAsc = btn.getAttribute('data-asc') === '1';
            getTbodies().forEach(function (tb) {
              sortTable(tb, state.sortColumn, state.sortAsc);
            });
            applyAll();
            toggleActive(btnSort, true);
            closeDropdown();
          });
        });
      });
    }

    document.addEventListener('click', function () { closeDropdown(); });
    document.addEventListener('ff-table-refresh', function () { applyAll(); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeDropdown();
    });

    applyAll();
    setTimeout(function () {
      applyAll();
    }, 400);
    return { applyAll: applyAll, state: state };
  }

  global.FleetFlowTableUtils = {
    searchTable: searchTable,
    filterTable: filterTable,
    sortTable: sortTable,
    groupTable: groupTable,
    init: init
  };
})(typeof window !== 'undefined' ? window : this);
