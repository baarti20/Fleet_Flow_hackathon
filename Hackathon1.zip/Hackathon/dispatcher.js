(function () {
  'use strict';

  var tripForm = document.getElementById('tripForm');
  var pointA = document.getElementById('pointA');
  var pointB = document.getElementById('pointB');
  var vehicleSelect = document.getElementById('vehicleSelect');
  var driverSelect = document.getElementById('driverSelect');
  var cargoWeight = document.getElementById('cargoWeight');
  var cargoError = document.getElementById('cargoError');
  var vehicleCapacityHint = document.getElementById('vehicleCapacityHint');
  var tripsTableBody = document.getElementById('tripsTableBody');
  var tripsCount = document.getElementById('tripsCount');

  var nextTripId = 1;
  var vehicles = [
    { id: 'v1', name: 'Tata Ace (MH-12-1001)', maxCapacityKg: 750 },
    { id: 'v2', name: 'Ashok Leyland Dost (MH-14-2002)', maxCapacityKg: 1500 },
    { id: 'v3', name: 'Eicher Pro (MH-01-3003)', maxCapacityKg: 2500 },
    { id: 'v4', name: 'Mahindra Blazo (MH-02-5005)', maxCapacityKg: 5000 },
    { id: 'v5', name: 'Bajaj Maxima (MH-43-4004)', maxCapacityKg: 300 }
  ];

  var drivers = [
    { id: 'd1', name: 'Raj Kumar' },
    { id: 'd2', name: 'Amit Sharma' },
    { id: 'd3', name: 'Priya Singh' },
    { id: 'd4', name: 'Vikram Patel' },
    { id: 'd5', name: 'Sneha Reddy' }
  ];

  var trips = [];

  function getVehicleById(id) {
    for (var i = 0; i < vehicles.length; i++) {
      if (vehicles[i].id === id) return vehicles[i];
    }
    return null;
  }

  function getDriverById(id) {
    for (var i = 0; i < drivers.length; i++) {
      if (drivers[i].id === id) return drivers[i];
    }
    return null;
  }

  var IN_SHOP_STORAGE_KEY = 'portal_vehicles_in_shop';
  var DRIVER_PROFILES_KEY = 'portal_driver_profiles';

  function getVehiclesInShop() {
    try {
      var raw = localStorage.getItem(IN_SHOP_STORAGE_KEY);
      if (!raw) return [];
      var arr = JSON.parse(raw);
      return Array.isArray(arr) ? arr : [];
    } catch (e) {
      return [];
    }
  }

  function vehiclesInUse() {
    var inUse = {};
    for (var i = 0; i < trips.length; i++) {
      var t = trips[i];
      if (t.status === 'draft' || t.status === 'dispatched') {
        inUse[t.vehicleId] = true;
        inUse[t.driverId] = true;
      }
    }
    var inShop = getVehiclesInShop();
    for (var j = 0; j < inShop.length; j++) {
      inUse[inShop[j]] = true;
    }
    return inUse;
  }

  function fillVehicleSelect() {
    if (!vehicleSelect) return;
    var inUse = vehiclesInUse();
    var current = vehicleSelect.value;
    vehicleSelect.innerHTML = '<option value="">Select vehicle...</option>';
    for (var i = 0; i < vehicles.length; i++) {
      var v = vehicles[i];
      if (inUse[v.id]) continue;
      var opt = document.createElement('option');
      opt.value = v.id;
      opt.textContent = v.name + ' (max ' + v.maxCapacityKg + ' kg)';
      opt.setAttribute('data-capacity', String(v.maxCapacityKg));
      vehicleSelect.appendChild(opt);
    }
    if (current && vehicleSelect.querySelector('option[value="' + current + '"]')) {
      vehicleSelect.value = current;
    }
    updateCapacityHint();
  }

  function getDriverProfiles() {
    try {
      var raw = localStorage.getItem(DRIVER_PROFILES_KEY);
      if (!raw) return {};
      return JSON.parse(raw);
    } catch (e) {
      return {};
    }
  }

  function isLicenseExpired(expiryStr) {
    if (!expiryStr) return false;
    return expiryStr < new Date().toISOString().slice(0, 10);
  }

  function isDriverBlocked(driverId) {
    var profiles = getDriverProfiles();
    var p = profiles[driverId];
    if (!p) return false;
    if (p.status === 'suspended') return true;
    if (isLicenseExpired(p.licenseExpiry)) return true;
    return false;
  }

  function fillDriverSelect() {
    if (!driverSelect) return;
    var inUse = vehiclesInUse();
    var current = driverSelect.value;
    driverSelect.innerHTML = '<option value="">Select driver...</option>';
    for (var i = 0; i < drivers.length; i++) {
      var d = drivers[i];
      if (inUse[d.id]) continue;
      if (isDriverBlocked(d.id)) continue;
      var opt = document.createElement('option');
      opt.value = d.id;
      opt.textContent = d.name;
      driverSelect.appendChild(opt);
    }
    if (current && driverSelect.querySelector('option[value="' + current + '"]')) {
      driverSelect.value = current;
    }
  }

  function updateCapacityHint() {
    if (!vehicleCapacityHint) return;
    var opt = vehicleSelect && vehicleSelect.options[vehicleSelect.selectedIndex];
    if (!opt || !opt.value) {
      vehicleCapacityHint.textContent = '';
      return;
    }
    var cap = opt.getAttribute('data-capacity');
    vehicleCapacityHint.textContent = 'Max capacity: ' + cap + ' kg';
  }

  function setTripStatus(tripId, status) {
    for (var i = 0; i < trips.length; i++) {
      if (trips[i].id === tripId) {
        trips[i].status = status;
        break;
      }
    }
    fillVehicleSelect();
    fillDriverSelect();
    renderTrips();
  }

  function escapeHtml(s) {
    var div = document.createElement('div');
    div.textContent = s;
    return div.innerHTML;
  }

  function renderTrips() {
    if (!tripsTableBody) return;
    tripsTableBody.innerHTML = trips.length === 0
      ? '<tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:2rem;">No trips yet. Create one above.</td></tr>'
      : trips.map(function (t) {
          var statusClass = t.status;
          var statusLabel = t.status.charAt(0).toUpperCase() + t.status.slice(1);
          var actions = '';
          if (t.status === 'draft') {
            actions = '<button type="button" class="btn-lifecycle btn-dispatch" data-id="' + t.id + '" data-action="dispatched">Dispatch</button> ' +
              '<button type="button" class="btn-lifecycle btn-cancel" data-id="' + t.id + '" data-action="cancelled">Cancel</button>';
          } else if (t.status === 'dispatched') {
            actions = '<button type="button" class="btn-lifecycle btn-complete" data-id="' + t.id + '" data-action="completed">Complete</button> ' +
              '<button type="button" class="btn-lifecycle btn-cancel" data-id="' + t.id + '" data-action="cancelled">Cancel</button>';
          }
          return '<tr>' +
            '<td>#' + t.id + '</td>' +
            '<td>' + escapeHtml(t.pointA) + '</td>' +
            '<td>' + escapeHtml(t.pointB) + '</td>' +
            '<td>' + escapeHtml(t.vehicleName) + '</td>' +
            '<td>' + escapeHtml(t.driverName) + '</td>' +
            '<td><span class="status-badge ' + statusClass + '">' + statusLabel + '</span></td>' +
            '<td><div class="cell-actions">' + actions + '</div></td>' +
            '</tr>';
        }).join('');

    if (tripsCount) tripsCount.textContent = trips.length + ' trip' + (trips.length === 1 ? '' : 's');

    tripsTableBody.querySelectorAll('.btn-lifecycle').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var id = parseInt(btn.getAttribute('data-id'), 10);
        var action = btn.getAttribute('data-action');
        if (id && action) setTripStatus(id, action);
      });
    });
  }

  tripForm.addEventListener('submit', function (e) {
    e.preventDefault();
    cargoError.textContent = '';

    var vId = (vehicleSelect && vehicleSelect.value) || '';
    var dId = (driverSelect && driverSelect.value) || '';
    var weight = parseInt(cargoWeight.value, 10);
    var v = getVehicleById(vId);

    if (!v) {
      cargoError.textContent = 'Please select a vehicle.';
      return;
    }
    if (weight > v.maxCapacityKg) {
      cargoError.textContent = 'Cargo weight (' + weight + ' kg) cannot exceed vehicle max capacity (' + v.maxCapacityKg + ' kg).';
      return;
    }
    if (isNaN(weight) || weight < 1) {
      cargoError.textContent = 'Enter a valid cargo weight.';
      return;
    }

    var driver = getDriverById(dId);
    if (!driver) {
      cargoError.textContent = 'Please select a driver.';
      return;
    }

    var a = (pointA.value || '').trim();
    var b = (pointB.value || '').trim();
    if (!a || !b) return;

    trips.push({
      id: nextTripId++,
      pointA: a,
      pointB: b,
      vehicleId: vId,
      vehicleName: v.name,
      driverId: dId,
      driverName: driver.name,
      cargoWeight: weight,
      maxCapacity: v.maxCapacityKg,
      status: 'draft'
    });

    tripForm.reset();
    vehicleCapacityHint.textContent = '';
    fillVehicleSelect();
    fillDriverSelect();
    renderTrips();
  });

  vehicleSelect.addEventListener('change', updateCapacityHint);

  fillVehicleSelect();
  fillDriverSelect();
  renderTrips();
})();
