# FleetFlow Database

SQL schema and seed data for the FleetFlow fleet management system.

## Tables

| Table | Purpose |
|-------|---------|
| **users** | Login/registration – email, password hash, name, role (manager/dispatcher) |
| **vehicles** | Vehicle registry – name, plate, capacity, odometer, status, type, region |
| **drivers** | Driver master list |
| **driver_profiles** | License expiry, completion rate, safety score, status |
| **trips** | Trip dispatcher – origin, destination, vehicle, driver, cargo, status |
| **vehicles_in_shop** | Vehicles currently in maintenance |
| **service_logs** | Maintenance/service logs (open/closed) |
| **fuel_logs** | Fuel entries – liters, cost, distance, date |
| **maintenance_costs** | Misc maintenance expenses |
| **vehicle_roi_config** | ROI input – acquisition cost, revenue (analytics) |

## Current App Mapping

The app currently uses **localStorage** and in-memory data. This schema matches those structures:

- `portal_service_logs` → **service_logs**
- `portal_fuel_logs` → **fuel_logs**
- `portal_maintenance_costs` → **maintenance_costs**
- `portal_vehicles_in_shop` → **vehicles_in_shop**
- `portal_driver_profiles` → **driver_profiles**
- `portal_vehicle_roi_config` → **vehicle_roi_config**
- Registry `vehicles` → **vehicles**
- Dispatcher `trips` → **trips**

## Usage

### SQLite (file-based)

```bash
cd database
sqlite3 fleetflow.db < schema.sql
sqlite3 fleetflow.db < seed.sql
```

### PostgreSQL

```bash
psql -U postgres -c "CREATE DATABASE fleetflow;"
psql -U postgres -d fleetflow -f schema.sql
psql -U postgres -d fleetflow -f seed.sql
```

### MySQL

```bash
mysql -u root -p < create-database.sql
mysql -u root -p fleetflow < schema.sql
mysql -u root -p fleetflow < seed.sql
```

> **Note:** For PostgreSQL, replace `INTEGER PRIMARY KEY AUTOINCREMENT` with `SERIAL PRIMARY KEY` and `INSERT OR IGNORE` with `INSERT ... ON CONFLICT DO NOTHING` if needed.

## Connected to FleetFlow

The database is now connected to the main project via:

1. **`server.js`** – Express + SQLite backend serving static files and REST API at `/api/*`
2. **`js/api.js`** – Shared API client used by all pages
3. All pages (registry, dispatcher, maintenance, expenses, analytics, drivers, dashboard) use the API instead of localStorage

### Run the app

```bash
npm install
npm start
```

Then open http://localhost:3000

> **Note:** For production, add proper password hashing (e.g. bcrypt) in the auth routes.
