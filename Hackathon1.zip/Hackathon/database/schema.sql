-- FleetFlow Database Schema
-- Compatible with SQLite, PostgreSQL, MySQL
-- Run this file to create the database structure

-- ============================================
-- Users & Authentication (Login, Registration)
-- ============================================
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  name VARCHAR(255) NOT NULL,
  role VARCHAR(50) NOT NULL CHECK (role IN ('manager', 'dispatcher')),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- Vehicles (Registry)
-- ============================================
CREATE TABLE IF NOT EXISTS vehicles (
  id VARCHAR(20) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  license_plate VARCHAR(50) NOT NULL UNIQUE,
  max_load_kg INTEGER NOT NULL,
  odometer INTEGER DEFAULT 0,
  out_of_service BOOLEAN DEFAULT 0,
  type VARCHAR(50) DEFAULT 'truck' CHECK (type IN ('truck', 'van', 'bike')),
  region VARCHAR(50) DEFAULT 'north' CHECK (region IN ('north', 'south', 'east', 'west')),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- Drivers
-- ============================================
CREATE TABLE IF NOT EXISTS drivers (
  id VARCHAR(20) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- Driver Profiles (Performance, License, Status)
-- ============================================
CREATE TABLE IF NOT EXISTS driver_profiles (
  driver_id VARCHAR(20) PRIMARY KEY,
  license_expiry DATE,
  trip_completion_rate INTEGER DEFAULT 100,
  safety_score INTEGER DEFAULT 100,
  status VARCHAR(50) DEFAULT 'on_duty' CHECK (status IN ('on_duty', 'off_duty', 'suspended')),
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (driver_id) REFERENCES drivers(id)
);

-- ============================================
-- Trips (Dispatcher)
-- ============================================
CREATE TABLE IF NOT EXISTS trips (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  origin VARCHAR(255) NOT NULL,
  destination VARCHAR(255) NOT NULL,
  vehicle_id VARCHAR(20) NOT NULL,
  driver_id VARCHAR(20) NOT NULL,
  cargo_weight_kg INTEGER NOT NULL,
  max_capacity_kg INTEGER NOT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'dispatched', 'completed', 'cancelled')),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id),
  FOREIGN KEY (driver_id) REFERENCES drivers(id)
);

-- ============================================
-- Vehicles In Shop (Maintenance status)
-- ============================================
CREATE TABLE IF NOT EXISTS vehicles_in_shop (
  vehicle_id VARCHAR(20) PRIMARY KEY,
  added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)
);

-- ============================================
-- Service Logs (Maintenance & Service)
-- ============================================
CREATE TABLE IF NOT EXISTS service_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  vehicle_id VARCHAR(20) NOT NULL,
  date DATE NOT NULL,
  type VARCHAR(100) NOT NULL,
  notes TEXT,
  cost DECIMAL(12,2),
  status VARCHAR(50) NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'closed')),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)
);

-- ============================================
-- Fuel Logs (Expenses)
-- ============================================
CREATE TABLE IF NOT EXISTS fuel_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  vehicle_id VARCHAR(20) NOT NULL,
  vehicle_name VARCHAR(255),
  liters DECIMAL(10,2) NOT NULL,
  cost DECIMAL(12,2) NOT NULL,
  distance_km DECIMAL(10,2),
  date DATE NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)
);

-- ============================================
-- Maintenance Costs (Misc Expenses)
-- ============================================
CREATE TABLE IF NOT EXISTS maintenance_costs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  vehicle_id VARCHAR(20) NOT NULL,
  vehicle_name VARCHAR(255),
  cost DECIMAL(12,2) NOT NULL,
  date DATE NOT NULL,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)
);

-- ============================================
-- Vehicle ROI Config (Analytics)
-- ============================================
CREATE TABLE IF NOT EXISTS vehicle_roi_config (
  vehicle_id VARCHAR(20) PRIMARY KEY,
  acquisition_cost DECIMAL(12,2) DEFAULT 500000,
  revenue DECIMAL(12,2) DEFAULT 600000,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)
);

-- ============================================
-- Indexes for common queries
-- ============================================
CREATE INDEX IF NOT EXISTS idx_trips_vehicle ON trips(vehicle_id);
CREATE INDEX IF NOT EXISTS idx_trips_driver ON trips(driver_id);
CREATE INDEX IF NOT EXISTS idx_trips_status ON trips(status);
CREATE INDEX IF NOT EXISTS idx_service_logs_vehicle ON service_logs(vehicle_id);
CREATE INDEX IF NOT EXISTS idx_service_logs_status ON service_logs(status);
CREATE INDEX IF NOT EXISTS idx_fuel_logs_vehicle ON fuel_logs(vehicle_id);
CREATE INDEX IF NOT EXISTS idx_fuel_logs_date ON fuel_logs(date);
CREATE INDEX IF NOT EXISTS idx_maintenance_costs_vehicle ON maintenance_costs(vehicle_id);
CREATE INDEX IF NOT EXISTS idx_vehicles_license ON vehicles(license_plate);
CREATE INDEX IF NOT EXISTS idx_vehicles_status ON vehicles(out_of_service);
