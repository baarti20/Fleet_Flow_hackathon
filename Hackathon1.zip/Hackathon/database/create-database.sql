-- FleetFlow: Create Database
-- Run this before schema.sql when using PostgreSQL or MySQL
-- SQLite: skip this file; schema.sql creates the .db file automatically

-- ============================================
-- PostgreSQL
-- Run: psql -U postgres -c "CREATE DATABASE fleetflow;"
-- Then: psql -U postgres -d fleetflow -f schema.sql
--       psql -U postgres -d fleetflow -f seed.sql
-- ============================================

-- ============================================
-- MySQL
-- Run: mysql -u root -p < create-database.sql
-- Then: mysql -u root -p fleetflow < schema.sql
--       mysql -u root -p fleetflow < seed.sql
-- ============================================
CREATE DATABASE IF NOT EXISTS fleetflow
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
